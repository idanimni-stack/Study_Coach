export async function askGemini(prompt: string, options?: { imageBase64?: string; mimeType?: string }) {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) return null;

  const parts: Array<Record<string, unknown>> = [{ text: prompt }];
  if (options?.imageBase64 && options?.mimeType) {
    parts.push({ inline_data: { mime_type: options.mimeType, data: options.imageBase64 } });
  }

  const response = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=${apiKey}`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      contents: [{ role: 'user', parts }],
      generationConfig: {
        temperature: 0.4,
        responseMimeType: 'application/json'
      }
    })
  });

  if (!response.ok) {
    const text = await response.text();
    throw new Error(text || 'Gemini request failed');
  }

  const data = await response.json();
  const text = data?.candidates?.[0]?.content?.parts?.[0]?.text;
  if (!text) return null;

  try {
    return JSON.parse(text);
  } catch {
    return { raw: text };
  }
}
