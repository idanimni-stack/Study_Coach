import { ThemeKey } from './types';

export const THEMES: Record<ThemeKey, { name: string; emoji: string; accent: string; accentSoft: string; bg: string }> = {
  football: { name: 'כדורגל', emoji: '⚽', accent: '#20c997', accentSoft: '#dff8ef', bg: 'linear-gradient(135deg, #0f3d2e, #1d7b5c)' },
  basketball: { name: 'כדורסל', emoji: '🏀', accent: '#ff922b', accentSoft: '#fff0e1', bg: 'linear-gradient(135deg, #7a2f00, #ff922b)' },
  space: { name: 'חלל', emoji: '🚀', accent: '#7c4dff', accentSoft: '#eee7ff', bg: 'linear-gradient(135deg, #150a3b, #4825a4)' },
  safari: { name: 'ספארי', emoji: '🦁', accent: '#8d6e63', accentSoft: '#f4ece7', bg: 'linear-gradient(135deg, #4b352d, #a57f6a)' },
  racing: { name: 'מרוצים', emoji: '🏎️', accent: '#ff4d6d', accentSoft: '#ffe3e8', bg: 'linear-gradient(135deg, #540b1d, #ff4d6d)' }
};
