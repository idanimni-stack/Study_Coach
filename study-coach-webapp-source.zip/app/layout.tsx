import './globals.css';
import type { Metadata } from 'next';

export const metadata: Metadata = {
  title: 'Study Coach Webapp',
  description: 'Hebrew-first adaptive study coach for math, English and more.'
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="he" dir="rtl">
      <body>{children}</body>
    </html>
  );
}
