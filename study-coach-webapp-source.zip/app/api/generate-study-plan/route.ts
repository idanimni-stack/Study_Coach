import { NextResponse } from 'next/server';
import { askGemini } from '@/lib/gemini';
import { buildFallbackSessions, inferTopics, uid } from '@/lib/mock';
import { Subject } from '@/lib/types';

export async function POST(req: Request) {
  const body = await req.json();
  const subject = (body.subject || 'math') as Subject;
  const examDate = body.examDate as string;
  const notes = (body.notes || '').toString();
  const language = (body.language || 'he') as 'he' | 'en' | 'mixed';
  const materialNames = Array.isArray(body.materialNames) ? body.materialNames : [];
  const inferredTopics = inferTopics(subject, `${notes} ${materialNames.join(' ')}`);

  try {
    const ai = await askGemini(`
Return strict JSON with keys: strengths (string[]), supportAreas (string[]), topics (string[]), dailySessions (array).
App language: Hebrew UI, but content language preference is ${language}.
Subject: ${subject}.
Exam date: ${examDate}.
Student materials summary: ${notes || 'No extra notes'}.
Uploaded material names: ${materialNames.join(', ') || 'none'}.
Requirements:
- Build a daily plan from today until the exam date.
- Every daily session needs: date, focus, goal, totalMinutes, tasks[].
- Each task needs: title, minutes, topic, type.
- Keep tasks realistic for ages 8-14.
- Tone should feel like a sports coach: encouraging, focused, energetic.
- If subject is math, include mixed review and error-correction tasks.
- If subject is english, include vocabulary, grammar, reading and writing balance.
`);

    if (ai && Array.isArray(ai.dailySessions)) {
      return NextResponse.json({
        id: uid('plan'),
        strengths: Array.isArray(ai.strengths) ? ai.strengths : ['מוטיבציה טובה'],
        supportAreas: Array.isArray(ai.supportAreas) ? ai.supportAreas : ['דיוק בבדיקה עצמית'],
        topics: Array.isArray(ai.topics) && ai.topics.length ? ai.topics : inferredTopics,
        dailySessions: ai.dailySessions,
      });
    }
  } catch (error) {
    console.error(error);
  }

  return NextResponse.json({
    id: uid('plan'),
    strengths: subject === 'english' ? ['אומץ להשתמש בשפה'] : ['נכונות לנסות ולפתור'],
    supportAreas: subject === 'english' ? ['אוצר מילים ודיוק דקדוקי'] : ['קריאת שאלה עד הסוף ובדיקת תשובה'],
    topics: inferredTopics,
    dailySessions: buildFallbackSessions(examDate, inferredTopics)
  });
}
