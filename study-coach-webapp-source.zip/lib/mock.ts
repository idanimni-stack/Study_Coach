import { AttemptFeedback, DailySession, Exercise, StudyPlan, Subject, ThemeKey } from './types';

export const todayIso = () => new Date().toISOString().slice(0, 10);

export function uid(prefix: string) {
  return `${prefix}_${Math.random().toString(36).slice(2, 10)}`;
}

export function addDays(base: string, days: number) {
  const d = new Date(base);
  d.setDate(d.getDate() + days);
  return d.toISOString().slice(0, 10);
}

export function inferTopics(subject: Subject, freeText: string): string[] {
  const text = freeText.toLowerCase();
  if (subject === 'english') {
    const pool = ['Vocabulary', 'Reading comprehension', 'Grammar', 'Spelling', 'Sentence building', 'Unseen text'];
    return pool.filter((t) => text.includes(t.toLowerCase().split(' ')[0])) || pool.slice(0, 4);
  }
  if (subject === 'math') {
    const pool = ['חיבור וחיסור', 'כפל וחילוק', 'שברים', 'בעיות מילוליות', 'גיאומטריה', 'מדידות', 'סדרות'];
    const selected = pool.filter((t) => text.includes(t.slice(0, 4)));
    return selected.length ? selected : pool;
  }
  return ['קריאה', 'הבנה', 'חזרה', 'תרגול'];
}

export function buildFallbackSessions(examDate: string, topics: string[]): DailySession[] {
  const today = new Date();
  const exam = new Date(examDate);
  const totalDays = Math.max(1, Math.ceil((exam.getTime() - today.getTime()) / 86400000));
  const dates: string[] = [];
  for (let i = 0; i <= totalDays; i += 1) {
    const d = new Date();
    d.setDate(today.getDate() + i);
    if (d <= exam) dates.push(d.toISOString().slice(0, 10));
  }
  return dates.map((date, index) => {
    const topic = topics[index % topics.length] || 'חזרה';
    const isLast = index === dates.length - 1;
    return {
      date,
      focus: isLast ? 'חזרה חכמה ומרגיעה' : topic,
      goal: isLast ? 'סגירת פינות אחרונות והורדת לחץ' : `להתקדם בביטחון בנושא ${topic}`,
      totalMinutes: isLast ? 20 : 25 + ((index % 3) * 5),
      tasks: [
        { title: 'חימום מהיר', minutes: 5, topic, type: 'warmup' },
        { title: `תרגול ממוקד - ${topic}`, minutes: isLast ? 8 : 12, topic, type: 'practice' },
        { title: 'בדיקת הבנה עם משוב', minutes: isLast ? 4 : 8, topic, type: 'review' },
        { title: isLast ? 'רק אם נשאר כוח: אתגר בונוס' : 'אתגר קטן', minutes: isLast ? 3 : 5, topic, type: 'challenge' }
      ]
    };
  });
}

export function fallbackExercise(subject: Subject, topic: string, difficulty: number): Exercise {
  if (subject === 'english') {
    const prompts = [
      { prompt: 'Write a short sentence using the word "because".', answer: 'Any correct sentence with because', hint: 'Use two ideas in one sentence.' },
      { prompt: 'Choose the correct verb: She ___ to school every day. (go / goes)', answer: 'goes', hint: 'Think about he/she/it.' },
      { prompt: 'Read and answer: Tom has 3 blue pencils and 2 red pencils. How many pencils does he have?', answer: '5', hint: 'Add both numbers.' }
    ];
    const p = prompts[(difficulty - 1) % prompts.length];
    return {
      id: uid('ex'),
      subject,
      topic,
      difficulty: Math.min(5, Math.max(1, difficulty)) as 1 | 2 | 3 | 4 | 5,
      prompt: p.prompt,
      expectedAnswer: p.answer,
      hint: p.hint,
      coachTip: 'קודם לחשוב, אחר כך לנסח בביטחון.'
    };
  }

  const prompts = [
    { prompt: 'חשבו: 384 + 216 = ?', answer: '600', hint: 'חברו מאות, עשרות ויחידות בנפרד.' },
    { prompt: 'חשבו: 7 × 8 = ?', answer: '56', hint: 'זה תרגיל מלוח הכפל.' },
    { prompt: 'לדני היו 12 גולות. הוא נתן 5 לחבר. כמה נשארו לו?', answer: '7', hint: 'זה תרגיל חיסור.' },
    { prompt: 'כתבו שבר שמייצג חצי מעוגה.', answer: '1/2', hint: 'חלק אחד מתוך שני חלקים שווים.' },
    { prompt: 'מה ההיקף של מלבן שאורכו 6 ורוחבו 3?', answer: '18', hint: 'מחברים את כל הצלעות.' }
  ];
  const p = prompts[(difficulty - 1) % prompts.length];
  return {
    id: uid('ex'),
    subject,
    topic,
    difficulty: Math.min(5, Math.max(1, difficulty)) as 1 | 2 | 3 | 4 | 5,
    prompt: p.prompt,
    expectedAnswer: p.answer,
    hint: p.hint,
    coachTip: 'כתוב מסודר על הדף, זה יעזור גם למוח וגם לבדיקה.'
  };
}

export function fallbackFeedback(expectedAnswer: string, studentAnswer: string): AttemptFeedback {
  const normalize = (v: string) => v.trim().toLowerCase();
  const cleanExpected = normalize(expectedAnswer);
  const cleanStudent = normalize(studentAnswer);
  const correct = cleanExpected && cleanStudent === cleanExpected;
  const partial = !correct && cleanStudent.length > 0;
  return {
    result: correct ? 'correct' : partial ? 'partial' : 'incorrect',
    summary: correct ? 'יש פגיעה מדויקת במטרה!' : partial ? 'יש התחלה טובה, אבל צריך ללטש.' : 'צריך לנסות שוב צעד-צעד.',
    finalAnswerFeedback: correct ? 'התשובה הסופית נכונה.' : `התשובה הסופית עדיין לא מדויקת. הכיוון הרצוי: ${expectedAnswer}`,
    methodFeedback: correct
      ? 'נראה שהדרך עבדה היטב. אם כתבת שלבים מסודרים - מעולה.'
      : 'בדוק אם חיברת/חיסרת/ניסחת לפי הסדר הנכון, ואם העתקת נכון את המספרים או המילים.',
    nextStep: correct ? 'עבור לאתגר הבא ברמה מעט גבוהה יותר.' : 'חזור על השלב הראשון, פתר שוב לאט, ואז השווה לתוצאה.',
    encouragement: correct ? 'אלוף! ממשיכים קדימה.' : 'לא נבהלים מטעות - ככה לומדים ומתחזקים.'
  };
}

export const starterPlan = (studentId: string): StudyPlan => ({
  id: uid('plan'),
  studentId,
  title: 'תוכנית דוגמה - מתמטיקה',
  subject: 'math',
  examDate: addDays(todayIso(), 10),
  materialsNotes: 'לוח הכפל, בעיות מילוליות, שברים והיקף.',
  materialNames: ['practice-sheet.pdf', 'topics.jpg'],
  language: 'he',
  topics: ['כפל וחילוק', 'בעיות מילוליות', 'שברים', 'גיאומטריה'],
  strengths: ['לוח הכפל הבסיסי', 'מוטיבציה גבוהה'],
  supportAreas: ['קריאה איטית של בעיות מילוליות', 'בדיקת תשובה סופית'],
  dailySessions: buildFallbackSessions(addDays(todayIso(), 10), ['כפל וחילוק', 'בעיות מילוליות', 'שברים', 'גיאומטריה'])
});

export const starterThemes: ThemeKey[] = ['football', 'basketball', 'space', 'safari', 'racing'];
