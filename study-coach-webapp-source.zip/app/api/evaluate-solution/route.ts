import { NextResponse } from 'next/server';
import { askGemini } from '@/lib/gemini';
import { fallbackFeedback } from '@/lib/mock';

export async function POST(req: Request) {
  const form = await req.formData();
  const prompt = form.get('prompt')?.toString() || '';
  const expectedAnswer = form.get('expectedAnswer')?.toString() || '';
  const studentAnswer = form.get('studentAnswer')?.toString() || '';
  const subject = form.get('subject')?.toString() || 'math';
  const topic = form.get('topic')?.toString() || '';
  const file = form.get('image') as File | null;

  try {
    let imageBase64: string | undefined;
    let mimeType: string | undefined;
    if (file && file.size > 0) {
      const bytes = await file.arrayBuffer();
      imageBase64 = Buffer.from(bytes).toString('base64');
      mimeType = file.type || 'image/jpeg';
    }

    const ai = await askGemini(`
Return strict JSON with keys: result, summary, finalAnswerFeedback, methodFeedback, nextStep, encouragement.
You are an upbeat sports coach for children aged 8-14.
Evaluate the student's answer.
Subject: ${subject}
Topic: ${topic}
Exercise prompt: ${prompt}
Expected answer: ${expectedAnswer}
Student typed answer: ${studentAnswer || 'No typed answer'}
If an image is provided, inspect the written work and comment on the method step-by-step.
result must be one of: correct, partial, incorrect.
All output should be in Hebrew unless the exercise is clearly in English.
` , imageBase64 && mimeType ? { imageBase64, mimeType } : undefined);

    if (ai?.result) {
      return NextResponse.json(ai);
    }
  } catch (error) {
    console.error(error);
  }

  return NextResponse.json(fallbackFeedback(expectedAnswer, studentAnswer));
}
