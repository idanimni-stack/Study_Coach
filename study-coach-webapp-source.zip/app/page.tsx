'use client';

import { useEffect, useMemo, useState } from 'react';
import { starterPlan, starterThemes, todayIso, uid } from '@/lib/mock';
import { THEMES } from '@/lib/theme';
import { AttemptFeedback, Exercise, Student, StudyPlan, Subject, ThemeKey } from '@/lib/types';

type PlanDraft = {
  title: string;
  subject: Subject;
  examDate: string;
  language: 'he' | 'en' | 'mixed';
  notes: string;
  files: File[];
};

const STORAGE_KEY = 'study-coach-v1';

const initialStudents: Student[] = [
  { id: 'stu_demo_1', name: 'אורי', ageBand: '8-10', avatar: '🦸', theme: 'space' },
  { id: 'stu_demo_2', name: 'נועה', ageBand: '11-14', avatar: '⚡', theme: 'football' }
];

const initialPlans: StudyPlan[] = [starterPlan('stu_demo_1')];

export default function HomePage() {
  const [students, setStudents] = useState<Student[]>(initialStudents);
  const [plans, setPlans] = useState<StudyPlan[]>(initialPlans);
  const [selectedStudentId, setSelectedStudentId] = useState<string>(initialStudents[0].id);
  const [selectedPlanId, setSelectedPlanId] = useState<string>(initialPlans[0].id);
  const [draft, setDraft] = useState<PlanDraft>({
    title: 'מבחן חדש',
    subject: 'math',
    examDate: new Date(Date.now() + 7 * 86400000).toISOString().slice(0, 10),
    language: 'he',
    notes: '',
    files: []
  });
  const [newStudentName, setNewStudentName] = useState('');
  const [exerciseTopic, setExerciseTopic] = useState('מעורב');
  const [difficulty, setDifficulty] = useState(2);
  const [exercise, setExercise] = useState<Exercise | null>(null);
  const [answer, setAnswer] = useState('');
  const [solutionImage, setSolutionImage] = useState<File | null>(null);
  const [feedback, setFeedback] = useState<AttemptFeedback | null>(null);
  const [loadingPlan, setLoadingPlan] = useState(false);
  const [loadingExercise, setLoadingExercise] = useState(false);
  const [loadingFeedback, setLoadingFeedback] = useState(false);

  useEffect(() => {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) {
      try {
        const parsed = JSON.parse(raw);
        if (parsed.students?.length) setStudents(parsed.students);
        if (parsed.plans?.length) setPlans(parsed.plans);
        if (parsed.selectedStudentId) setSelectedStudentId(parsed.selectedStudentId);
        if (parsed.selectedPlanId) setSelectedPlanId(parsed.selectedPlanId);
      } catch {}
    }
  }, []);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify({ students, plans, selectedStudentId, selectedPlanId }));
  }, [students, plans, selectedStudentId, selectedPlanId]);

  const selectedStudent = students.find((s) => s.id === selectedStudentId) || students[0];
  const studentPlans = plans.filter((p) => p.studentId === selectedStudentId);
  const selectedPlan = studentPlans.find((p) => p.id === selectedPlanId) || studentPlans[0] || null;
  const theme = THEMES[(selectedStudent?.theme || 'space') as ThemeKey];

  useEffect(() => {
    if (studentPlans.length && !studentPlans.some((p) => p.id === selectedPlanId)) {
      setSelectedPlanId(studentPlans[0].id);
    }
  }, [selectedStudentId, selectedPlanId, studentPlans]);

  const todaySession = useMemo(() => {
    if (!selectedPlan) return null;
    return selectedPlan.dailySessions.find((session) => session.date >= todayIso()) || selectedPlan.dailySessions[0];
  }, [selectedPlan]);

  const stats = useMemo(() => {
    if (!selectedPlan) return { daysLeft: 0, topics: 0, minutes: 0 };
    const examTime = new Date(selectedPlan.examDate).getTime();
    const daysLeft = Math.max(0, Math.ceil((examTime - Date.now()) / 86400000));
    const minutes = selectedPlan.dailySessions.reduce((sum, item) => sum + item.totalMinutes, 0);
    return { daysLeft, topics: selectedPlan.topics.length, minutes };
  }, [selectedPlan]);

  function addStudent() {
    const name = newStudentName.trim();
    if (!name) return;
    const themeKey = starterThemes[students.length % starterThemes.length];
    const student: Student = {
      id: uid('stu'),
      name,
      ageBand: '8-10',
      avatar: ['🦸', '🌟', '🚀', '🏆', '🧠'][students.length % 5],
      theme: themeKey
    };
    setStudents((current) => [...current, student]);
    setSelectedStudentId(student.id);
    setNewStudentName('');
  }

  async function createPlan() {
    if (!selectedStudent) return;
    setLoadingPlan(true);
    try {
      const response = await fetch('/api/generate-study-plan', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          subject: draft.subject,
          examDate: draft.examDate,
          notes: draft.notes,
          language: draft.language,
          materialNames: draft.files.map((file) => file.name)
        })
      });
      const data = await response.json();
      const plan: StudyPlan = {
        id: data.id,
        studentId: selectedStudent.id,
        title: draft.title,
        subject: draft.subject,
        examDate: draft.examDate,
        materialsNotes: draft.notes,
        materialNames: draft.files.map((file) => file.name),
        language: draft.language,
        topics: data.topics || [],
        strengths: data.strengths || [],
        supportAreas: data.supportAreas || [],
        dailySessions: data.dailySessions || []
      };
      setPlans((current) => [plan, ...current]);
      setSelectedPlanId(plan.id);
      setExercise(null);
      setFeedback(null);
      setAnswer('');
    } finally {
      setLoadingPlan(false);
    }
  }

  async function getExercise() {
    if (!selectedPlan) return;
    setLoadingExercise(true);
    setFeedback(null);
    setAnswer('');
    try {
      const response = await fetch('/api/generate-exercise', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          subject: selectedPlan.subject,
          topic: exerciseTopic,
          difficulty,
          language: selectedPlan.language
        })
      });
      const data = await response.json();
      setExercise(data);
    } finally {
      setLoadingExercise(false);
    }
  }

  async function evaluateExercise() {
    if (!exercise) return;
    setLoadingFeedback(true);
    const form = new FormData();
    form.append('prompt', exercise.prompt);
    form.append('expectedAnswer', exercise.expectedAnswer);
    form.append('studentAnswer', answer);
    form.append('subject', exercise.subject);
    form.append('topic', exercise.topic);
    if (solutionImage) form.append('image', solutionImage);

    try {
      const response = await fetch('/api/evaluate-solution', { method: 'POST', body: form });
      const data = await response.json();
      setFeedback(data);
      if (data.result === 'correct') setDifficulty((value) => Math.min(5, value + 1));
      if (data.result === 'incorrect') setDifficulty((value) => Math.max(1, value - 1));
    } finally {
      setLoadingFeedback(false);
    }
  }

  return (
    <main className="shell" style={{ ['--accent' as string]: theme.accent, ['--accent-soft' as string]: theme.accentSoft }}>
      <section className="hero" style={{ background: theme.bg }}>
        <div className="hero-grid">
          <div>
            <span className="badge">{theme.emoji} Study Coach לילדים - Web App</span>
            <h1 style={{ margin: '16px 0 10px', fontSize: 'clamp(2rem, 5vw, 3.4rem)' }}>
              מתאמנים חכם לקראת מבחן. כל יום יודעים בדיוק מה לעשות.
            </h1>
            <p style={{ maxWidth: 760, lineHeight: 1.7 }}>
              אפליקציית Web בעברית שמרכזת תלמידים, תוכניות לימוד, אבחון רמה, תרגול אדפטיבי, משוב כמו מאמן ספורט,
              וצילום פתרון על דף לקבלת פידבק על הדרך ולא רק על התשובה הסופית.
            </p>
            <div className="inline" style={{ marginTop: 18 }}>
              <span className="badge">⚡ קישור פשוט לשיתוף אחרי פריסה ל-Vercel</span>
              <span className="badge">📚 מתמטיקה + אנגלית + מקצועות נוספים</span>
              <span className="badge">📷 העלאת תמונות ופתרונות</span>
            </div>
          </div>
          <div className="panel" style={{ alignSelf: 'stretch' }}>
            <h3 className="section-title">לוח מחוונים מהיר</h3>
            <div className="kpi-grid">
              <div className="card"><div className="muted small">תלמידים</div><strong style={{ fontSize: '1.8rem' }}>{students.length}</strong></div>
              <div className="card"><div className="muted small">תוכניות</div><strong style={{ fontSize: '1.8rem' }}>{plans.length}</strong></div>
              <div className="card"><div className="muted small">ימים למבחן</div><strong style={{ fontSize: '1.8rem' }}>{stats.daysLeft}</strong></div>
            </div>
            <div className="card" style={{ marginTop: 12 }}>
              <div className="muted small">מסר למאמן של היום</div>
              <div style={{ fontWeight: 700, marginTop: 8 }}>“מסיימים את המשימה היומית, ואז חופש בראש שקט לחברים ולחוגים.”</div>
            </div>
          </div>
        </div>
      </section>

      <section className="main-grid">
        <aside className="panel">
          <h3 className="section-title">תלמידים ותמה</h3>
          <div className="student-grid">
            {students.map((student) => (
              <button key={student.id} className={`student-card ${student.id === selectedStudentId ? 'active' : ''}`} onClick={() => setSelectedStudentId(student.id)}>
                <div style={{ fontSize: '1.8rem' }}>{student.avatar}</div>
                <div style={{ fontWeight: 800, marginTop: 8 }}>{student.name}</div>
                <div className="muted small">גילאים {student.ageBand} · {THEMES[student.theme].name}</div>
              </button>
            ))}
          </div>

          <div className="field" style={{ marginTop: 14 }}>
            <label>הוספת תלמיד חדש</label>
            <input value={newStudentName} onChange={(e) => setNewStudentName(e.target.value)} placeholder="שם תלמיד" />
          </div>
          <button className="soft-button" onClick={addStudent}>➕ הוספת תלמיד</button>

          <h3 className="section-title" style={{ marginTop: 18 }}>בחירת תמה</h3>
          <div className="theme-grid">
            {starterThemes.map((key) => (
              <button
                key={key}
                className="theme-button"
                style={{ background: THEMES[key].bg, outline: selectedStudent?.theme === key ? '3px solid white' : 'none' }}
                onClick={() => setStudents((current) => current.map((student) => student.id === selectedStudentId ? { ...student, theme: key } : student))}
              >
                <div style={{ fontSize: '1.6rem' }}>{THEMES[key].emoji}</div>
                <div style={{ fontWeight: 800 }}>{THEMES[key].name}</div>
              </button>
            ))}
          </div>

          <p className="muted small" style={{ marginTop: 14 }}>
            במבנה פריסה רגיל ל-Vercel אפשר לשתף לינק אחד פשוט לילדים, בלי התקנות ובלי הסתבכות.
          </p>
        </aside>

        <section style={{ display: 'grid', gap: 18 }}>
          <div className="panel">
            <h3 className="section-title">בניית תוכנית אימון חדשה</h3>
            <div className="task-grid">
              <div className="field">
                <label>שם התוכנית</label>
                <input value={draft.title} onChange={(e) => setDraft({ ...draft, title: e.target.value })} placeholder="למשל: מבחן מתמטיקה יוני" />
              </div>
              <div className="field">
                <label>מקצוע</label>
                <select value={draft.subject} onChange={(e) => setDraft({ ...draft, subject: e.target.value as Subject })}>
                  <option value="math">מתמטיקה</option>
                  <option value="english">אנגלית</option>
                  <option value="other">אחר</option>
                </select>
              </div>
              <div className="field">
                <label>תאריך מבחן</label>
                <input type="date" value={draft.examDate} onChange={(e) => setDraft({ ...draft, examDate: e.target.value })} />
              </div>
              <div className="field">
                <label>שפת התוכן</label>
                <select value={draft.language} onChange={(e) => setDraft({ ...draft, language: e.target.value as 'he' | 'en' | 'mixed' })}>
                  <option value="he">עברית</option>
                  <option value="en">English</option>
                  <option value="mixed">משולב</option>
                </select>
              </div>
            </div>
            <div className="field">
              <label>חומר לימודי / פירוט חופשי</label>
              <textarea
                value={draft.notes}
                onChange={(e) => setDraft({ ...draft, notes: e.target.value })}
                placeholder="אפשר להדביק נושאים מהמורה, מטרות, חולשות, או פירוט חופשי לקראת המבחן."
              />
            </div>
            <div className="field">
              <label>קבצים רלוונטיים</label>
              <input
                type="file"
                multiple
                accept=".pdf,.doc,.docx,.ppt,.pptx,image/*"
                onChange={(e) => setDraft({ ...draft, files: Array.from(e.target.files || []) })}
              />
              <div className="muted small">תומך ב-PDF, Word, PowerPoint, צילומים ותמונות. הקבצים נשמרים לשלב החיבור ל-Supabase Storage.</div>
              {draft.files.length > 0 && <ul className="material-list">{draft.files.map((file) => <li key={file.name}>{file.name}</li>)}</ul>}
            </div>
            <div className="inline">
              <button className="primary-button" onClick={createPlan} disabled={loadingPlan}>{loadingPlan ? 'בונה תוכנית...' : 'בנה תוכנית יומית עד המבחן'}</button>
              <button className="ghost-button" onClick={() => setDraft({ ...draft, notes: '' })}>נקה טקסט</button>
            </div>
          </div>

          <div className="panel">
            <div style={{ display: 'flex', justifyContent: 'space-between', gap: 12, flexWrap: 'wrap', alignItems: 'center' }}>
              <h3 className="section-title" style={{ margin: 0 }}>תוכניות של {selectedStudent?.name}</h3>
              {selectedPlan && <span className="badge">🎯 {selectedPlan.title}</span>}
            </div>
            <div className="plan-list">
              {studentPlans.length === 0 && <div className="muted">עדיין אין תוכניות לתלמיד הזה.</div>}
              {studentPlans.map((plan) => (
                <button key={plan.id} className={`plan-card ${plan.id === selectedPlanId ? 'active' : ''}`} onClick={() => setSelectedPlanId(plan.id)}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', gap: 10, flexWrap: 'wrap' }}>
                    <strong>{plan.title}</strong>
                    <span className="tag">{plan.subject === 'math' ? 'מתמטיקה' : plan.subject === 'english' ? 'אנגלית' : 'אחר'}</span>
                  </div>
                  <div className="muted small" style={{ marginTop: 6 }}>מבחן: {plan.examDate}</div>
                  <div className="tag-row" style={{ marginTop: 10 }}>{plan.topics.slice(0, 5).map((topic) => <span className="tag" key={topic}>{topic}</span>)}</div>
                </button>
              ))}
            </div>
          </div>

          {selectedPlan && (
            <>
              <div className="panel">
                <h3 className="section-title">אבחון ותוכנית יומית</h3>
                <div className="kpi-grid">
                  <div className="card"><div className="muted small">נושאים מזוהים</div><strong>{stats.topics}</strong></div>
                  <div className="card"><div className="muted small">סה"כ דקות תוכנית</div><strong>{stats.minutes}</strong></div>
                  <div className="card"><div className="muted small">קבצים שצורפו</div><strong>{selectedPlan.materialNames.length}</strong></div>
                </div>
                <div className="card" style={{ marginTop: 12 }}>
                  <div style={{ fontWeight: 800, marginBottom: 8 }}>חוזקות התחלתיות</div>
                  <div className="tag-row">{selectedPlan.strengths.map((item) => <span key={item} className="tag">{item}</span>)}</div>
                  <div style={{ fontWeight: 800, margin: '14px 0 8px' }}>חיזוקים שכדאי לעבוד עליהם</div>
                  <div className="tag-row">{selectedPlan.supportAreas.map((item) => <span key={item} className="tag">{item}</span>)}</div>
                </div>
                {todaySession && (
                  <div className="card" style={{ marginTop: 12 }}>
                    <div className="badge">📅 המשימה של היום · {todaySession.date}</div>
                    <h4 style={{ marginBottom: 6 }}>{todaySession.focus}</h4>
                    <p className="muted">{todaySession.goal}</p>
                    {todaySession.tasks.map((task) => (
                      <div className="session-row" key={`${todaySession.date}-${task.title}`}>
                        <strong>{task.minutes} דק'</strong>
                        <div>
                          <div style={{ fontWeight: 800 }}>{task.title}</div>
                          <div className="muted small">נושא: {task.topic}</div>
                        </div>
                        <span className="tag">{task.type}</span>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              <div className="panel">
                <h3 className="section-title">תרגול אדפטיבי עם פידבק</h3>
                <div className="task-grid">
                  <div className="field">
                    <label>נושא לתרגול</label>
                    <select value={exerciseTopic} onChange={(e) => setExerciseTopic(e.target.value)}>
                      <option value="מעורב">מעורב</option>
                      {selectedPlan.topics.map((topic) => <option key={topic} value={topic}>{topic}</option>)}
                    </select>
                  </div>
                  <div className="field">
                    <label>רמת קושי</label>
                    <input type="range" min={1} max={5} value={difficulty} onChange={(e) => setDifficulty(Number(e.target.value))} />
                    <div className="muted small">{difficulty} / 5</div>
                  </div>
                </div>
                <button className="primary-button" onClick={getExercise} disabled={loadingExercise}>{loadingExercise ? 'מכין תרגיל...' : 'צור תרגיל חדש'}</button>

                {exercise && (
                  <div className="exercise-box" style={{ marginTop: 16 }}>
                    <div className="card">
                      <div className="badge">🧩 {exercise.topic}</div>
                      <h4 style={{ fontSize: '1.25rem', marginBottom: 6 }}>{exercise.prompt}</h4>
                      <p className="muted">רמז: {exercise.hint}</p>
                      <p><strong>טיפ מאמן:</strong> {exercise.coachTip}</p>
                    </div>

                    <div className="field">
                      <label>תשובה סופית</label>
                      <input value={answer} onChange={(e) => setAnswer(e.target.value)} placeholder="כתוב את התשובה הסופית" />
                    </div>
                    <div className="field">
                      <label>צילום הפתרון מהמחברת</label>
                      <input type="file" accept="image/*" onChange={(e) => setSolutionImage(e.target.files?.[0] || null)} />
                      <div className="muted small">אפשר להעלות צילום כדי לקבל פידבק גם על הדרך, לא רק על התוצאה.</div>
                    </div>
                    <div className="exercise-actions">
                      <button className="primary-button" onClick={evaluateExercise} disabled={loadingFeedback}>{loadingFeedback ? 'בודק פתרון...' : 'בדוק וקבל פידבק'}</button>
                      <button className="soft-button" onClick={() => { setAnswer(''); setFeedback(null); }}>נקה תשובה</button>
                    </div>
                  </div>
                )}

                {feedback && (
                  <div className={`feedback ${feedback.result}`} style={{ marginTop: 16 }}>
                    <strong style={{ fontSize: '1.15rem' }}>{feedback.summary}</strong>
                    <p><strong>על התשובה:</strong> {feedback.finalAnswerFeedback}</p>
                    <p><strong>על הדרך:</strong> {feedback.methodFeedback}</p>
                    <p><strong>הצעד הבא:</strong> {feedback.nextStep}</p>
                    <p><strong>מילת עידוד:</strong> {feedback.encouragement}</p>
                  </div>
                )}
              </div>
            </>
          )}
        </section>
      </section>

      <div className="footer-note">נבנה כ-MVP פריס ל-Vercel, עם הכנה לחיבור Supabase ו-Gemini לצורך חוויית WebApp פשוטה עם קישור אחד לילדים.</div>
    </main>
  );
}
