create table if not exists students (
  id uuid primary key default gen_random_uuid(),
  display_name text not null,
  avatar text,
  age_band text check (age_band in ('8-10','11-14')),
  theme text,
  created_at timestamptz default now()
);

create table if not exists study_plans (
  id uuid primary key default gen_random_uuid(),
  student_id uuid references students(id) on delete cascade,
  title text not null,
  subject text not null,
  exam_date date not null,
  language text not null default 'he',
  notes text,
  strengths jsonb default '[]'::jsonb,
  support_areas jsonb default '[]'::jsonb,
  topics jsonb default '[]'::jsonb,
  daily_sessions jsonb default '[]'::jsonb,
  created_at timestamptz default now()
);

create table if not exists uploaded_materials (
  id uuid primary key default gen_random_uuid(),
  study_plan_id uuid references study_plans(id) on delete cascade,
  file_name text not null,
  mime_type text,
  storage_path text,
  created_at timestamptz default now()
);

create table if not exists exercise_attempts (
  id uuid primary key default gen_random_uuid(),
  study_plan_id uuid references study_plans(id) on delete cascade,
  exercise_payload jsonb not null,
  student_answer text,
  solution_image_path text,
  feedback jsonb,
  created_at timestamptz default now()
);
