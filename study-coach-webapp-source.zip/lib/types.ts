export type Subject = 'math' | 'english' | 'other';

export type ThemeKey = 'football' | 'basketball' | 'space' | 'safari' | 'racing';

export interface Student {
  id: string;
  name: string;
  ageBand: '8-10' | '11-14';
  avatar: string;
  theme: ThemeKey;
}

export interface PlanTask {
  title: string;
  minutes: number;
  topic: string;
  type: 'warmup' | 'practice' | 'review' | 'challenge';
}

export interface DailySession {
  date: string;
  focus: string;
  goal: string;
  totalMinutes: number;
  tasks: PlanTask[];
}

export interface StudyPlan {
  id: string;
  studentId: string;
  title: string;
  subject: Subject;
  examDate: string;
  materialsNotes: string;
  materialNames: string[];
  language: 'he' | 'en' | 'mixed';
  topics: string[];
  strengths: string[];
  supportAreas: string[];
  dailySessions: DailySession[];
}

export interface Exercise {
  id: string;
  subject: Subject;
  topic: string;
  difficulty: 1 | 2 | 3 | 4 | 5;
  prompt: string;
  expectedAnswer: string;
  hint: string;
  coachTip: string;
}

export interface AttemptFeedback {
  result: 'correct' | 'partial' | 'incorrect';
  summary: string;
  finalAnswerFeedback: string;
  methodFeedback: string;
  nextStep: string;
  encouragement: string;
}
