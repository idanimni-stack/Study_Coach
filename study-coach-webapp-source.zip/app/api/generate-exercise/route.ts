import { NextResponse } from 'next/server';
import { askGemini } from '@/lib/gemini';
import { fallbackExercise } from '@/lib/mock';
import { Subject } from '@/lib/types';

export async function POST(req: Request) {
  const body = await req.json();
  const subject = (body.subject || 'math') as Subject;
  const topic = (body.topic || 'Mixed').toString();
  const difficulty = Number(body.difficulty || 2);
  const language = (body.language || 'he').toString();

  try {
    const ai = await askGemini(`
Return strict JSON with keys: prompt, expectedAnswer, hint, coachTip.
Create ONE exercise for a learner aged 8-14.
Subject: ${subject}
Topic: ${topic}
Difficulty: ${difficulty} / 5
Language preference: ${language}
Rules:
- Keep prompt short and clear.
- expectedAnswer should be brief and machine-checkable when possible.
- hint should not reveal the full answer.
- coachTip should sound like a fun sports coach.
`);

    if (ai?.prompt) {
      return NextResponse.json({
        id: `ex_${Date.now()}`,
        subject,
        topic,
        difficulty,
        prompt: ai.prompt,
        expectedAnswer: ai.expectedAnswer || '',
        hint: ai.hint || '',
        coachTip: ai.coachTip || 'ניגשים באומץ ובסדר.'
      });
    }
  } catch (error) {
    console.error(error);
  }

  return NextResponse.json(fallbackExercise(subject, topic, difficulty));
}
